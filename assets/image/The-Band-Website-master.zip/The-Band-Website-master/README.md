# The Band Website

**The Band** is a simple responsive website created using HTML, CSS and JavaScript deployed on Netlify.
Link: [Click me](https://musicband.netlify.com)
